<?php
function custom_enqueue_options_style() {
    
    wp_enqueue_style( 'new-custom-style', get_stylesheet_directory_uri() . '/assets/css/custom.css' );
wp_enqueue_style( 'mytheme-bootstrap-style', get_stylesheet_directory_uri() . '/assets/css/bootstrap.min.css' );
    wp_enqueue_script( 'jquery-bootstrap-popup-js', get_stylesheet_directory_uri() . '/assets/js/bootstrap.min.js' );
    wp_enqueue_script( 'jquery-custom-js', get_stylesheet_directory_uri() . '/assets/js/custom.js' );
}
add_action( 'wp_enqueue_scripts', 'custom_enqueue_options_style', 500 );

function custom_admin_enqueue(){
    wp_enqueue_script('customscript-custom', get_stylesheet_directory_uri() . '/assets/js/admin-custom.js', array(), '1.0.0', true );
}
add_action('admin_enqueue_scripts', 'custom_admin_enqueue');

add_filter( 'woocommerce_product_upsells_products_heading', 'bbloomer_translate_may_also_like' );
  
function bbloomer_translate_may_also_like() {
   return 'Works well with';
}

add_filter( 'woocommerce_product_add_to_cart_text', 'custom_add_to_cart_price', 20, 2 ); // Shop and other archives pages
add_filter( 'woocommerce_product_single_add_to_cart_text', 'custom_add_to_cart_price', 20, 2 ); // Single product pages
function custom_add_to_cart_price( $button_text, $product ) {
    // Variable products
    if( $product->is_type('variable') ) {
        // shop and archives
        if( ! is_product() ){
            $product_price = wc_price( wc_get_price_to_display( $product, array( 'price' => $product->get_variation_price() ) ) );
            //return $button_text . ' - From ' . strip_tags( $product_price );
            return 'From ' . strip_tags( $product_price );
        } 
        // Single product pages
        else {
            return $button_text;
        }
    } 
    // All other product types
    else {
        $product_price = wc_price( wc_get_price_to_display( $product ) );
        //return 'Add To Bag - ' . strip_tags( $product_price );
        return 'Add To Bag';
    }
}

/*add_filter( 'woocommerce_product_tabs', 'woo_custom_description_tab', 98 );
function woo_custom_description_tab( $tabs ) {

	$tabs['reviews']['callback'] = 'woo_custom_description_tab_content';	// Custom description callback

	return $tabs;
}

function woo_custom_description_tab_content() {
    echo do_shortcode('[wp_social_ninja id="36299" platform="reviews"]');
}*/

add_filter( 'woocommerce_product_tabs', 'misha_rename_additional_info_tab' );

function misha_rename_additional_info_tab( $tabs ) {

	$tabs['reviews']['title'] = 'Reviews';

	return $tabs;

}

add_filter( 'woocommerce_product_tabs', 'bbloomer_remove_desc_tab', 9999 );
function bbloomer_remove_desc_tab( $tabs ) {
   unset( $tabs['description'] );
   unset( $tabs['additional_information'] );
   return $tabs;
}
/*
add_action('wp_head',function (){
    if(!is_page('contact')){
        echo '<script src="https://www.google.com/recaptcha/api.js" async defer></script>';
    }
    }
);

function action_woocommerce_checkout_after_customer_details( $wccm_checkout_text_after ) {
    echo '<div class="g-recaptcha" data-sitekey="6LffZw0gAAAAAMX2sgXiFyUmNMPxfHOiUgqBi8ps"></div>';
}
add_action( 'woocommerce_checkout_after_customer_details', 'action_woocommerce_checkout_after_customer_details', 10, 1 ); 


function insert_custom_captcha(){ ?>
    <script>
        jQuery('<div class="g-recaptcha" data-sitekey="6LffZw0gAAAAAMX2sgXiFyUmNMPxfHOiUgqBi8ps"></div>').insertAfter('form.woocommerce-form-register .woocommerce-privacy-policy-text');
    </script>
<?php
}
add_action('wp_footer', 'insert_custom_captcha', 50);*/


function remove_checkout_fields( $fields ){
     unset($fields['billing']['billing_state']);
     unset($fields['billing']['billing_postcode']);

     return $fields;
}
add_filter( 'woocommerce_checkout_fields' , 'remove_checkout_fields' );

add_filter('b2bking_bulkorder_indigo_search_name_display', function($name, $product){
    $name = $product->get_name();
    return $name;
}, 10, 2);

  
function custom_login_form() {
   if ( is_admin() ) return;
   if ( is_user_logged_in() ) return; 
   ob_start();
   woocommerce_login_form();
   return ob_get_clean();
}
add_shortcode( 'wc_login_form_custom', 'custom_login_form' );


function change_login_form_label( $translated_text, $text, $domain ) {
    if ( ! is_user_logged_in() ) {
        $original_text = 'Username or email address';

        if ( $text === $original_text )
            $translated_text = esc_html__('Username', 'astra-child' );
    }
    return $translated_text;
}
add_filter( 'gettext', 'change_login_form_label', 10, 3 );


function login_redirect(){
    if(  is_user_logged_in() && is_page('login') && !is_admin() ){
        wp_redirect(site_url('my-account'));
    }
}
add_action('wp', 'login_redirect');


// remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
// add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 30 );